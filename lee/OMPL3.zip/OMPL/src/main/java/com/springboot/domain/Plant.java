package com.springboot.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Plant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "member_id")
    private User member;

    @Column(nullable = false, length = 12)
    private String plantNickname;

    private LocalDate startDate;

    @Column(nullable = false, length = 30)
    private String plantType;

    private String photo;

    @Column(nullable = false)
    private int plantLevel = 1;

    @OneToMany(mappedBy = "plant", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PlantPhoto> photos = new ArrayList<>();

    public Plant() {
    }

    public Plant(Long id,
                 User member,
                 String plantNickname,
                 LocalDate startDate,
                 String plantType,
                 String photo,
                 int plantLevel,
                 List<PlantPhoto> photos) {
        this.id = id;
        this.member = member;
        this.plantNickname = plantNickname;
        this.startDate = startDate;
        this.plantType = plantType;
        this.photo = photo;
        this.plantLevel = plantLevel;
        this.photos = photos;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getMember() {
        return member;
    }

    public void setMember(User member) {
        this.member = member;
    }

    public String getPlantNickname() {
        return plantNickname;
    }

    public void setPlantNickname(String plantNickname) {
        this.plantNickname = plantNickname;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public String getPlantType() {
        return plantType;
    }

    public void setPlantType(String plantType) {
        this.plantType = plantType;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public int getPlantLevel() {
        return plantLevel;
    }

    public void setPlantLevel(int plantLevel) {
        this.plantLevel = plantLevel;
    }

    public List<PlantPhoto> getPhotos() {
        return photos;
    }

    public void setPhotos(List<PlantPhoto> photos) {
        this.photos = photos;
    }
}