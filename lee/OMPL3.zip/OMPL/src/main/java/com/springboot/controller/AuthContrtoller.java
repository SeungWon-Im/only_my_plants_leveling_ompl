package com.springboot.controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.domain.User;
import com.springboot.repository.UserRepository;

@Controller
@RequestMapping("/home")
public class AuthContrtoller {

    private final UserRepository users;
    private final PasswordEncoder encoder;

    public AuthContrtoller(UserRepository users, PasswordEncoder encoder) {
        this.users = users;
        this.encoder = encoder;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/loginfailed")
    public String loginerror(Model model) {
        model.addAttribute("error", "true");
        return "login";
    }

    @GetMapping("/signup")
    public String signupForm() {
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@RequestParam("username") String username,
                         @RequestParam("nickname") String nickname,
                         @RequestParam("password") String password) {
        if (!username.matches("[A-Za-z0-9]{4,16}") || nickname.isBlank() || password.length() < 4)
            return "redirect:/home/signup?error=invalid";
        if (users.existsById(username))
            return "redirect:/home/signup?error=exists";

        User u = new User();
        u.setId(username);
        u.setNickname(nickname.trim());
        u.setPwd(encoder.encode(password));
        users.save(u);
        return "redirect:/home/login?joined";
    }
}