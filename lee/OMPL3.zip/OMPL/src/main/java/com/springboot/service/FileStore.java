package com.springboot.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

@Component
public class FileStore {

    private static final Map<String, String> EXT = Map.of(
            "image/jpeg", ".jpg", "image/png", ".png",
            "image/webp", ".webp", "image/gif", ".gif");

    private final Path dir;

    public FileStore(@Value("${app.upload-dir}") String uploadDir) throws IOException {
        this.dir = Path.of(uploadDir).toAbsolutePath();
        Files.createDirectories(dir);
    }

    public Path dir() {
        return dir;
    }

    public String save(MultipartFile file) {
        String type = file.getContentType();
        String ext = type == null ? null : EXT.get(type);
        if (ext == null)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "jpg, png, webp, gif 이미지만 올릴 수 있어요.");
        String name = UUID.randomUUID() + ext;
        try {
            file.transferTo(dir.resolve(name));
        } catch (IOException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "사진을 저장하지 못했어요.");
        }
        return name;
    }

    public void delete(String name) {
        if (name == null) return;
        try {
            Files.deleteIfExists(dir.resolve(name));
        } catch (IOException ignored) {
        }
    }
}