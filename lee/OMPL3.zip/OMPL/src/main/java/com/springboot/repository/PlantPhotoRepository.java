package com.springboot.repository;

import java.time.LocalDate;
import org.springframework.data.jpa.repository.JpaRepository;
import com.springboot.domain.Plant;
import com.springboot.domain.PlantPhoto;

public interface PlantPhotoRepository extends JpaRepository<PlantPhoto, Long> {
    boolean existsByPlantAndTakenOn(Plant plant, LocalDate takenOn);
    long countByPlant(Plant plant);
}