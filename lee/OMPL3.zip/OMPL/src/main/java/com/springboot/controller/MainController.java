package com.springboot.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/home")
public class MainController {

	@GetMapping
	public String main(Authentication authentication, Model model) {
	    boolean loggedIn = authentication != null
	            && authentication.isAuthenticated()
	            && !(authentication instanceof AnonymousAuthenticationToken);
	    model.addAttribute("loggedIn", loggedIn);
	    return "main";
	}

//	@GetMapping("/signup")
//	public String signup() {
//		return "signup";
//	}
//	@GetMapping("/registplant")
//	public String registraionFrom() {
//		return "registration";
//	}
//	@GetMapping("/myplant")
//	public String plantlistFrom() {
//		return "plant";
//	}
}