package com.springboot.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.springboot.service.FileStore;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final FileStore files;

    public WebConfig(FileStore files) {
        this.files = files;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String location = files.dir().normalize().toUri().toString();
        if (!location.endsWith("/")) {
            location = location + "/";
        }

        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(location);
    }
}