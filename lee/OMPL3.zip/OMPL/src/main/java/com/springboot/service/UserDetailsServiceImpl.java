package com.springboot.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.springboot.domain.User;
import com.springboot.repository.UserRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository users;

    public UserDetailsServiceImpl(UserRepository users) {
        this.users = users;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User u = users.findById(username)
                .orElseThrow(() -> new UsernameNotFoundException("없는 아이디"));
        // 시큐리티의 User 는 이름이 겹쳐서 전체 경로로 써요
        return org.springframework.security.core.userdetails.User
                .withUsername(u.getId())
                .password(u.getPwd())
                .roles("USER")
                .build();
    }
}