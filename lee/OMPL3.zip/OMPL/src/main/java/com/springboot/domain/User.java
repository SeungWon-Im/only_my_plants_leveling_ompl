package com.springboot.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "member")
public class User {

    @Id
    @Column(length = 16)
    private String id;

    @Column(nullable = false, length = 100)
    private String pwd;

    @Column(nullable = false, length = 10)
    private String nickname;

    public User() {
    }

    public User(String id, String pwd, String nickname) {
        this.id = id;
        this.pwd = pwd;
        this.nickname = nickname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
}