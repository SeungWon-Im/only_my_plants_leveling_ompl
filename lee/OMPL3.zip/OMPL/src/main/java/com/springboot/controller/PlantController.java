package com.springboot.controller;

import java.net.URI;
import java.security.Principal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import com.springboot.domain.Plant;
import com.springboot.domain.PlantPhoto;
import com.springboot.repository.PlantPhotoRepository;
import com.springboot.repository.PlantRepository;
import com.springboot.repository.UserRepository;
import com.springboot.service.FileStore;
import com.springboot.service.Humidity;

@Controller
@RequestMapping("/plants")
@SuppressWarnings({"rawtypes", "unchecked"})
public class PlantController {

    private final UserRepository users;
    private final PlantRepository plants;
    private final PlantPhotoRepository photos;
    private final FileStore files;
    private final Humidity humidityService;
    private final RestTemplate restTemplate = new RestTemplate();

    public PlantController(UserRepository users,
                           PlantRepository plants,
                           PlantPhotoRepository photos,
                           FileStore files,
                           Humidity humidityService) {
        this.users = users;
        this.plants = plants;
        this.photos = photos;
        this.files = files;
        this.humidityService = humidityService;
    }

    /** iNaturalist 식물 검색 API (/plants/api/search?q=...) */
    @GetMapping("/api/search")
    @ResponseBody
    public List searchPlants(@RequestParam(name = "q", defaultValue = "") String q) {
        String keyword = q.trim();
        if (keyword.isBlank()) {
            return List.of();
        }
        return fetchFromInaturalist(keyword);
    }

    /** 선택한 식물 이름 기준 정보 조회 (/plants/api/info?name=...) */
    @GetMapping("/api/info")
    @ResponseBody
    public Map getPlantInfo(@RequestParam(name = "name", defaultValue = "") String name) {
        String keyword = name.trim();
        if (!keyword.isBlank()) {
            List found = fetchFromInaturalist(keyword);
            if (!found.isEmpty()) {
                return (Map) found.get(0);
            }
        }
        return buildPlantInfo(keyword, null);
    }

    /** 라즈베리파이 실시간 습도 수신 (POST /plants/{id}/humidity) */
    @PostMapping("/{id}/humidity")
    @ResponseBody
    public ResponseEntity postHumidity(@PathVariable("id") Long id,
                                       @RequestBody Map body) {
        Object rawHumidity = body.get("humidity");
        if (rawHumidity == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "humidity 값이 필요해요."));
        }
        Double humidity;
        try {
            humidity = Double.valueOf(String.valueOf(rawHumidity));
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "humidity는 숫자여야 해요."));
        }
        if (!plants.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "식물을 찾을 수 없어요.");
        }
        humidityService.updateHumidity(id, humidity);
        return ResponseEntity.ok(Map.of("plantId", id, "humidity", humidity));
    }

    /** 라즈베리파이 실시간 습도 조회 (GET /plants/{id}/humidity) */
    @GetMapping("/{id}/humidity")
    @ResponseBody
    public Map getHumidity(@PathVariable("id") Long id) {
        Map res = new LinkedHashMap();
        res.put("plantId", id);
        res.put("humidity", humidityService.getHumidity(id));
        return res;
    }

    /** 내 식물 목록 */
    @GetMapping
    public String list(Principal principal, Model model) {
        List myPlants = plants.findByMember_IdOrderByIdAsc(principal.getName());
        Map infoMap = new LinkedHashMap();
        Map humidityMap = new LinkedHashMap();

        for (Object obj : myPlants) {
            Plant p = (Plant) obj;
            infoMap.put(p.getId(), getPlantInfo(p.getPlantType()));
            humidityMap.put(p.getId(), humidityService.getHumidity(p.getId()));
        }

        model.addAttribute("plants", myPlants);
        model.addAttribute("plantInfoMap", infoMap);
        model.addAttribute("humidityMap", humidityMap);
        return "plant";
    }

    /** 등록 화면 */
    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("plant", new Plant());
        return "registration";
    }

    /** 등록 -> DB 저장 */
    @PostMapping
    @Transactional
    public String create(@RequestParam("plantNickname") String plantNickname,
                         @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                         @RequestParam("plantType") String plantType,
                         @RequestParam(name = "photo", required = false) MultipartFile photo,
                         Principal principal) {
        Plant p = new Plant();
        p.setMember(users.findById(principal.getName()).orElseThrow());
        fill(p, plantNickname, startDate, plantType, photo);
        plants.save(p);
        return "redirect:/plants";
    }

    /** 수정 화면 */
    @GetMapping("/{id}/edit")
    @Transactional(readOnly = true)
    public String editForm(@PathVariable("id") Long id, Principal principal, Model model) {
        model.addAttribute("plant", own(id, principal.getName()));
        return "registration";
    }

    /** 수정 -> DB 업데이트 */
    @PostMapping("/{id}")
    @Transactional
    public String update(@PathVariable("id") Long id,
                         @RequestParam("plantNickname") String plantNickname,
                         @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                         @RequestParam("plantType") String plantType,
                         @RequestParam(name = "photo", required = false) MultipartFile photo,
                         Principal principal) {
        Plant p = own(id, principal.getName());
        fill(p, plantNickname, startDate, plantType, photo);
        return "redirect:/plants";
    }

    /** 삭제 (DB 식물·일일사진 및 업로드 파일 함께 삭제) */
    @PostMapping("/{id}/delete")
    @Transactional
    public String delete(@PathVariable("id") Long id, Principal principal) {
        Plant p = own(id, principal.getName());
        files.delete(p.getPhoto());
        p.getPhotos().forEach(ph -> files.delete(ph.getFileName()));
        humidityService.removeHumidity(p.getId());
        plants.delete(p);
        return "redirect:/plants";
    }

    /** 오늘 사진 올리기: 하루 한 장, 3장마다 레벨업 */
    @PostMapping("/{id}/photos")
    @Transactional
    public String uploadDaily(@PathVariable("id") Long id,
                              @RequestParam("file") MultipartFile file,
                              Principal principal) {
        Plant p = own(id, principal.getName());
        LocalDate today = LocalDate.now();
        if (!photos.existsByPlantAndTakenOn(p, today)) {
            PlantPhoto ph = new PlantPhoto();
            ph.setPlant(p);
            ph.setTakenOn(today);
            ph.setFileName(files.save(file));
            photos.save(ph);
            p.setPlantLevel((int) (photos.countByPlant(p) / 3) + 1);
        }
        return "redirect:/plants";
    }

    private List fetchFromInaturalist(String keyword) {
        List list = new ArrayList();
        try {
            URI uri = UriComponentsBuilder
                    .fromUriString("https://api.inaturalist.org/v1/taxa")
                    .queryParam("q", keyword)
                    .queryParam("locale", "ko")
                    .queryParam("per_page", 8)
                    .build()
                    .encode()
                    .toUri();

            Map response = restTemplate.getForObject(uri, Map.class);
            if (response == null) {
                return list;
            }
            Object rawResults = response.get("results");
            if (rawResults instanceof List) {
                List resultsList = (List) rawResults;
                for (Object obj : resultsList) {
                    if (obj instanceof Map) {
                        Map taxon = (Map) obj;
                        String commonName = taxon.get("preferred_common_name") != null
                                ? String.valueOf(taxon.get("preferred_common_name")) : "";
                        String sciName = taxon.get("name") != null
                                ? String.valueOf(taxon.get("name")) : keyword;
                        String displayName = !commonName.isBlank() ? commonName : sciName;
                        String summary = taxon.get("wikipedia_summary") != null
                                ? String.valueOf(taxon.get("wikipedia_summary")).replaceAll("<[^>]*>", "").trim() : "";
                        list.add(buildPlantInfo(displayName, summary));
                    }
                }
            }
        } catch (Exception e) {
            return new ArrayList();
        }
        return list;
    }

    private Map buildPlantInfo(String name, String summary) {
        String safeName = (name == null || name.isBlank()) ? "내 식물" : name.trim();
        String desc;
        if (summary != null && !summary.isBlank()) {
            desc = summary.length() > 140 ? summary.substring(0, 140) + "..." : summary;
        } else {
            desc = safeName + " 정보예요. 흙 상태를 확인하며 알맞은 빛과 통풍을 유지해 주세요.";
        }
        Map info = new LinkedHashMap();
        info.put("name", safeName);
        info.put("watering", "7일마다");
        info.put("humidity", "보통 (40~60%)");
        info.put("desc", desc);
        return info;
    }


    private void fill(Plant p,
                      String nickname,
                      LocalDate startDate,
                      String type,
                      MultipartFile photo) {
        if (nickname.isBlank() || nickname.trim().length() > 12 || type.isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "별명(12자 이하)과 식물 종류를 입력해주세요.");
        }
        p.setPlantNickname(nickname.trim());
        p.setStartDate(startDate);
        p.setPlantType(type.trim());
        if (photo != null && !photo.isEmpty()) {
            files.delete(p.getPhoto());
            p.setPhoto(files.save(photo));
        }
    }

    private Plant own(Long id, String memberId) {
        return plants.findById(id)
                .filter(p -> p.getMember().getId().equals(memberId))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "식물을 찾을 수 없어요."));
    }
}