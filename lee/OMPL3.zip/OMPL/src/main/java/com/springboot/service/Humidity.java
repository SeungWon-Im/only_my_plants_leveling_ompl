package com.springboot.service;


import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

@Service
public class Humidity {

    private final Map<Long, Double> latestHumidity = new ConcurrentHashMap<>();

    public void updateHumidity(Long plantId, Double humidity) {
        if (plantId != null && humidity != null) {
            latestHumidity.put(plantId, humidity);
        }
    }

    public Double getHumidity(Long plantId) {
        return latestHumidity.get(plantId);
    }

    public void removeHumidity(Long plantId) {
        if (plantId != null) {
            latestHumidity.remove(plantId);
        }
    }
}