package com.springboot.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.springboot.domain.Plant;

public interface PlantRepository extends JpaRepository<Plant, Long> {
    List<Plant> findByMember_IdOrderByIdAsc(String memberId);
}