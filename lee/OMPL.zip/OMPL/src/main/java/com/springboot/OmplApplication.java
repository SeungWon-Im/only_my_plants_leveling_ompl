package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmplApplication {

	public static void main(String[] args) {
		SpringApplication.run(OmplApplication.class, args);
	}

}
