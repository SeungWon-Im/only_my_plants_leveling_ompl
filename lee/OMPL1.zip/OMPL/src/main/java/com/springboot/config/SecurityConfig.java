package com.springboot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    protected PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    protected SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
        .csrf(AbstractHttpConfigurer::disable)
        .authorizeHttpRequests(
        	authorizeHttpRequests -> authorizeHttpRequests
        		.requestMatchers("/home/plants").hasRole("USER")
        		.requestMatchers("/css/**", "/js/**", "/images/**").permitAll()
        	    .requestMatchers("/", "/home", "/home/login", "/home/loginfailed", "/home/signup", "/error").permitAll()
                .anyRequest().authenticated())
            .formLogin(form -> form
                .loginPage("/home/login")
                .loginProcessingUrl("/home/login")
                .defaultSuccessUrl("/home", true)
                .failureUrl("/home/loginfailed"))
            .logout(logout -> logout
                .logoutUrl("/home/logout")
                .logoutSuccessUrl("/home")
                .invalidateHttpSession(true));
        return http.build();
    }

    /** DB 연결 전 임시 계정: test / 1234 */
    @Bean
    protected UserDetailsService userDetailsService(PasswordEncoder encoder) {
        UserDetails user = org.springframework.security.core.userdetails.User
                .withUsername("test")
                .password(encoder.encode("1234"))
                .roles("USER")
                .build();
        return new InMemoryUserDetailsManager(user);
    }
}