package com.springboot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import com.springboot.domain.OmplDomain;
import com.springboot.repository.LoginRepository;
import org.springframework.http.HttpMethod;


@Configuration
@EnableWebSecurity
public class SecurityConfiguration {
	@Bean 
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
		
	@Autowired
	LoginRepository loginRepository;

	@Bean
	public UserDetailsService users() {
	    return username -> {
	        OmplDomain member = loginRepository.findByUsername(username);

	        if (member == null) {
	            throw new UsernameNotFoundException("회원이 없습니다.");
	        }

	        return User.builder()
	                .username(member.getUsername())
	                .password(member.getPassword())
	                .roles(member.getRole())
	                .build();
	    };
	}
		
	@Bean
	public SecurityFilterChain securityfilterchain(HttpSecurity http) throws Exception {
		http
		.authorizeHttpRequests(
	        	authorizeRequests -> authorizeRequests        	
	        	.requestMatchers("/login", "/signup", "/home").permitAll()
	        	.requestMatchers(HttpMethod.POST, "/api/sensor").permitAll()   // 추가: 라즈베리가 보내는 곳
	        	.anyRequest().authenticated()
	       )
		.csrf(csrf -> csrf.ignoringRequestMatchers("/api/sensor"))
		.formLogin( 
			        formLogin->formLogin				    
					   .loginPage("/login") // 사용자 정의 로그인 페이지
					   .loginProcessingUrl("/login") 
					   .defaultSuccessUrl("/home") // 로그인 성공 후 이동 페이지    
					   .usernameParameter("username") 
			 		   .passwordParameter("password")
				       .failureUrl("/login?error") // 로그인 실패 후 이동 페이지, ?error : error라는 추가 정보를 붙여서 줌 (파라미터)
			       ) 
				  
			.logout(logout -> logout
					 .logoutUrl("/logout")    // 이경로도 자동으로 처리된다. 별도로 작성할 필요가 없다.          		
			         .logoutSuccessUrl("/home")
			       );
		    return http.build();
	}
}

