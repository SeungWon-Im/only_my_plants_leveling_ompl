package com.springboot.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.domain.SensorDomain;

@RestController
@RequestMapping("/api/sensor")
public class SensorController {

    // 이 시간(15초)보다 오래된 값은 보여 주지 않음 (라즈베리가 꺼졌을 때 옛 값이 남지 않게)
    private static final long FRESH_MILLIS = 5_000;

    private volatile SensorDomain latest;   // 가장 최근에 받은 값
    private volatile long receivedAt;       // 받은 시각

    // 라즈베리파이가 습도를 보내는 곳 (POST /api/sensor)
    @PostMapping
    public ResponseEntity<String> receive(@RequestBody SensorDomain data) {
        if (data.getHumidity() == null) {
            return ResponseEntity.badRequest().body("humidity required");
        }

        latest = data;
        receivedAt = System.currentTimeMillis();
        return ResponseEntity.ok("ok");
    }

    // 웹페이지가 최신 습도를 가져가는 곳 (GET /api/sensor). 값이 없거나 오래됐으면 204
    @GetMapping
    public ResponseEntity<SensorDomain> get() {
        if (latest == null || System.currentTimeMillis() - receivedAt > FRESH_MILLIS) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(latest);
    }
}