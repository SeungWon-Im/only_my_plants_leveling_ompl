package com.springboot.domain;

import lombok.Data;

@Data
public class SensorDomain {
    private Double humidity;      // 습도(%)
    private Double temperature;   // 온도(°C)
}