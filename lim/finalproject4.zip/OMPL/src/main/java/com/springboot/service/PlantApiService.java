package com.springboot.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.domain.PlantApiDomain;
import com.springboot.repository.PlantApiRepository;

@Service
public class PlantApiService {

    private static final int PAGE_SIZE = 100;
    private static final int MAX_PAGES = 50;

    @Autowired
    PlantApiClient apiClient;

    @Autowired
    PlantApiRepository plantApiRepository;

    // 등록 화면의 드롭다운용 전체 목록
    public List<PlantApiDomain> findAll() {
        return plantApiRepository.findAll();
    }

    // 확인용: 이름 검색
    public List<PlantApiDomain> search(String keyword) {
        return apiClient.search(keyword);
    }

    // 확인용: 상세
    public PlantApiDomain getDetail(String contentNo) {
        return apiClient.getDetail(contentNo);
    }

    // DB가 비어 있으면 API에서 전체 식물을 받아 변환한 뒤 저장 (저장한 개수 반환)
    public int loadIfEmpty() {
        if (plantApiRepository.count() > 0) {
            return 0;
        }

        Set<String> seen = new HashSet<>();
        int saved = 0;

        for (int page = 1; page <= MAX_PAGES; page++) {
            List<PlantApiDomain> list = apiClient.getPage(page, PAGE_SIZE);

            boolean added = false;
            for (PlantApiDomain item : list) {
                // 같은 식물이 반복되면 건너뜀
                if (item.getContentNo() == null || !seen.add(item.getContentNo())) {
                    continue;
                }
                added = true;

                PlantApiDomain detail = apiClient.getDetail(item.getContentNo());
                if (detail == null) {
                    continue;
                }

                detail.setName(item.getName());   // 이름은 목록의 것을 사용
                convert(detail);                  // 코드 → 숫자
                // 조언 정보와 관리 정보가 모두 없는 식물은 저장하지 않음
                if (detail.getDescription() == null || detail.getDescription().isBlank()) {
                    continue;
                }
                plantApiRepository.save(detail);
                saved++;
            }

            // 새로 얻은 식물이 없으면 끝
            if (!added) {
                break;
            }
        }
        return saved;
    }

    // API 코드를 숫자로 변환
    private void convert(PlantApiDomain api) {

        // 습도 코드 → 최소·최대(%)
        String hd = api.getHumidityCode() == null ? "" : api.getHumidityCode();
        switch (hd) {
            case "083001" -> { api.setHumidityMin(0);  api.setHumidityMax(40); }
            case "083002" -> { api.setHumidityMin(40); api.setHumidityMax(70); }
            case "083003" -> { api.setHumidityMin(70); api.setHumidityMax(100); }
            default -> { }
        }

        // 겨울 물주기 코드 → 일 수 (일 수는 우리가 정한 값)
        String water = api.getWaterWinterCode() == null ? "" : api.getWaterWinterCode();
        Integer days = switch (water) {
            case "053001" -> 2;
            case "053002" -> 3;
            case "053003" -> 7;
            case "053004" -> 14;
            default -> null;
        };
        api.setWaterCycleDays(days);
    }
}