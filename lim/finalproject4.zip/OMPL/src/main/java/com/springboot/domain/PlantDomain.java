package com.springboot.domain;

import java.time.LocalDate;

import lombok.Data;

@Data
public class PlantDomain {
    private Long id;
    private Long memberId;
    private String nickname;
    private String species;
    private String description;
    private String humidity;
    private Integer waterCycleDays;
    private LocalDate startDate;
    private int level;
}