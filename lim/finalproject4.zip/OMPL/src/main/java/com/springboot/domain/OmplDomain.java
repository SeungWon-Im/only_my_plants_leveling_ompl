package com.springboot.domain;

import java.time.LocalDate;

import lombok.Data;

@Data
public class OmplDomain {
    private Long id;
    private String username;
    private String password;
    private String nickname;
    private String role;
}