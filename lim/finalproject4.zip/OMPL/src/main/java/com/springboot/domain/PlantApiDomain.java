package com.springboot.domain;

import lombok.Data;

@Data
public class PlantApiDomain {
    private Long id;                  // DB 번호
    private String contentNo;         // 농사로 식물 번호
    private String name;              // 식물 이름
    private String humidityCode;      // API 습도 코드 (변환할 때만 사용, DB에 저장 안 함)
    private String waterWinterCode;   // API 겨울 물주기 코드 (변환할 때만 사용, DB에 저장 안 함)
    private Integer humidityMin;      // 습도 최소(%)
    private Integer humidityMax;      // 습도 최대(%)
    private Integer waterCycleDays;   // 물주기(일, 겨울 기준)
    private String description;       // 특징
}