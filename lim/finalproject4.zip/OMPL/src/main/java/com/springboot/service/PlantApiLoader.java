package com.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class PlantApiLoader implements ApplicationRunner {

    @Autowired
    PlantApiService plantApiService;

    @Override
    public void run(ApplicationArguments args) {
        try {
            int saved = plantApiService.loadIfEmpty();
            System.out.println("식물 API 데이터 저장: " + saved + "건");
        } catch (Exception e) {
            // 실패해도 서버는 계속 실행 (키가 들어 있는 주소는 출력하지 않음)
            System.out.println("식물 API 데이터 저장 실패: " + e.getMessage());
        }
    }
}