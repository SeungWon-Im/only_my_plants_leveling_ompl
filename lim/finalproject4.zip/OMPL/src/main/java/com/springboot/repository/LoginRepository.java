package com.springboot.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.springboot.domain.OmplDomain;

@Repository
public class LoginRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    // 회원 저장 (회원가입)
    public void save(OmplDomain member) {
        String sql = "INSERT INTO member (username, password, nickname) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, member.getUsername(), member.getPassword(), member.getNickname());
    }

    // 아이디로 회원 조회 (로그인)
    public OmplDomain findByUsername(String username) {
        String sql = "SELECT * FROM member WHERE username=?";
        List<OmplDomain> list = jdbcTemplate.query(sql,
                BeanPropertyRowMapper.newInstance(OmplDomain.class), username);
        return list.isEmpty() ? null : list.get(0);
    }
}