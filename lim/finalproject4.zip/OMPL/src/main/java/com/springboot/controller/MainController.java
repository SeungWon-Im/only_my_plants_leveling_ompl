package com.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.service.MemberService;
import com.springboot.service.MemberService.SignupResult;

@Controller
public class MainController {

    @Autowired
    MemberService memberService;

    @GetMapping("/home")
    public String mainForm() {
        return "main";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @GetMapping("/signup")
    public String signupForm() {
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@RequestParam("username") String username,
                         @RequestParam("password") String password,
                         @RequestParam("passwordConfirm") String passwordConfirm,
                         @RequestParam("nickname") String nickname) {

        SignupResult result = memberService.signup(username, password, passwordConfirm, nickname);

        return switch (result) {
            case PASSWORD_MISMATCH -> "redirect:/signup?mismatch";
            case USERNAME_EXISTS -> "redirect:/signup?error";
            case SUCCESS -> "redirect:/login";
        };
    }
}