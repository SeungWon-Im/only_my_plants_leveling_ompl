package com.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.springboot.domain.OmplDomain;
import com.springboot.repository.LoginRepository;

@Service
public class MemberService {

    // 회원가입 결과
    public enum SignupResult {
        SUCCESS, PASSWORD_MISMATCH, USERNAME_EXISTS
    }

    @Autowired
    LoginRepository loginRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    // 회원가입
    public SignupResult signup(String username, String password, String passwordConfirm, String nickname) {

        // 비밀번호와 비밀번호 확인이 다르면 가입하지 않음
        if (!password.equals(passwordConfirm)) {
            return SignupResult.PASSWORD_MISMATCH;
        }

        // 이미 있는 아이디면 가입하지 않음
        if (loginRepository.findByUsername(username) != null) {
            return SignupResult.USERNAME_EXISTS;
        }

        OmplDomain member = new OmplDomain();
        member.setUsername(username);
        member.setPassword(passwordEncoder.encode(password));   // 암호화해서 저장
        member.setNickname(nickname);

        try {
            loginRepository.save(member);
        } catch (DuplicateKeyException e) {
            // 확인한 직후 같은 아이디로 동시에 가입된 경우 (DB의 UNIQUE가 막아 줌)
            return SignupResult.USERNAME_EXISTS;
        }

        return SignupResult.SUCCESS;
    }
}