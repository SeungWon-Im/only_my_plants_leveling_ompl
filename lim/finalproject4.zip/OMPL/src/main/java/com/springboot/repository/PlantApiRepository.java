package com.springboot.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.springboot.domain.PlantApiDomain;

@Repository
public class PlantApiRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    // 저장된 개수
    public int count() {
        Integer count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM plant_api", Integer.class);
        return count == null ? 0 : count;
    }

    // 저장
    public void save(PlantApiDomain api) {
        String sql = "INSERT INTO plant_api (content_no, name, humidity_min, humidity_max, water_cycle_days, description) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                api.getContentNo(),
                api.getName(),
                api.getHumidityMin(),
                api.getHumidityMax(),
                api.getWaterCycleDays(),
                api.getDescription());
    }

    // 전체 목록 (이름순)
    public List<PlantApiDomain> findAll() {
        String sql = "SELECT * FROM plant_api ORDER BY name";
        return jdbcTemplate.query(sql, BeanPropertyRowMapper.newInstance(PlantApiDomain.class));
    }

    // 번호로 한 개 조회 (없으면 null)
    public PlantApiDomain findById(Long id) {
        String sql = "SELECT * FROM plant_api WHERE id=?";
        List<PlantApiDomain> list = jdbcTemplate.query(sql,
                BeanPropertyRowMapper.newInstance(PlantApiDomain.class), id);
        return list.isEmpty() ? null : list.get(0);
    }
}