package com.springboot.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.springboot.domain.PlantDomain;

import java.time.LocalDate;

@Repository
public class PlantRepository {

    @Autowired
    JdbcTemplate jdbcTemplate;

    // 식물 저장 (식물 등록)
    public void save(PlantDomain plant) {
        String sql = "INSERT INTO plant (member_id, nickname, species, description, humidity, water_cycle_days, start_date) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        jdbcTemplate.update(sql,
                plant.getMemberId(),
                plant.getNickname(),
                plant.getSpecies(),
                plant.getDescription(),
                plant.getHumidity(),
                plant.getWaterCycleDays(),
                plant.getStartDate());
    }

    // 회원 번호로 식물 조회 (없으면 null)
    public PlantDomain findByMemberId(Long memberId) {
        String sql = "SELECT * FROM plant WHERE member_id=?";
        List<PlantDomain> list = jdbcTemplate.query(sql,
                BeanPropertyRowMapper.newInstance(PlantDomain.class), memberId);
        return list.isEmpty() ? null : list.get(0);
    }
    
    // 사진 저장 (파일 이름 + 올린 날짜)
    public void addPhoto(Long plantId, String fileName, LocalDate takenOn) {
        String sql = "INSERT INTO plant_photo (plant_id, file_name, taken_on) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, plantId, fileName, takenOn);
    }

    // 그 날짜에 올린 사진이 있는지
    public boolean hasPhotoOn(Long plantId, LocalDate day) {
        String sql = "SELECT COUNT(*) FROM plant_photo WHERE plant_id=? AND taken_on=?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, plantId, day);
        return count != null && count > 0;
    }

    // 사진 개수
    public int countPhotos(Long plantId) {
        String sql = "SELECT COUNT(*) FROM plant_photo WHERE plant_id=?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, plantId);
        return count == null ? 0 : count;
    }

    // 가장 최근 사진 파일 이름 (없으면 null)
    public String findLatestPhoto(Long plantId) {
        String sql = "SELECT file_name FROM plant_photo WHERE plant_id=? ORDER BY id DESC LIMIT 1";
        List<String> list = jdbcTemplate.queryForList(sql, String.class, plantId);
        return list.isEmpty() ? null : list.get(0);
    }
    
    // 식물 삭제 (사진 기록도 함께 삭제됨)
    public void deletePlant(Long plantId) {
        String sql = "DELETE FROM plant WHERE id=?";
        jdbcTemplate.update(sql, plantId);
    }

    // 사진 파일 이름 전체 (삭제할 때 파일도 지우기 위해 사용)
    public List<String> findPhotoNames(Long plantId) {
        String sql = "SELECT file_name FROM plant_photo WHERE plant_id=?";
        return jdbcTemplate.queryForList(sql, String.class, plantId);
    }
    
    // 레벨 변경
    public void updateLevel(Long plantId, int level) {
        String sql = "UPDATE plant SET level=? WHERE id=?";
        jdbcTemplate.update(sql, level, plantId);
    }
}