package com.springboot.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.springboot.domain.OmplDomain;
import com.springboot.domain.PlantDomain;
import com.springboot.repository.LoginRepository;
import com.springboot.repository.PlantRepository;

import java.util.Set;
import java.util.UUID;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.springboot.domain.PlantApiDomain;
import com.springboot.repository.PlantApiRepository;

@Service
public class PlantService {

    @Autowired
    LoginRepository loginRepository;

    @Autowired
    PlantRepository plantRepository;
    
    @Autowired
    PlantApiRepository plantApiRepository;

    @Value("${app.upload-dir}")
    String uploadDir;
    
    private static final Set<String> ALLOWED_EXT = Set.of(".jpg", ".jpeg", ".png", ".gif", ".webp");

    // 사진 3장마다 1레벨
    private static final int PHOTOS_PER_LEVEL = 3;

    // 한국 시간 기준 오늘 날짜
    public LocalDate today() {
        return LocalDate.now(ZoneId.of("Asia/Seoul"));
    }

    // 로그인 아이디로 그 회원의 식물 조회 (없으면 null)
    public PlantDomain findByUsername(String username) {
        return plantRepository.findByMemberId(getMemberId(username));
    }

    // 식물 등록 (회원당 1개만). 선택한 API 식물 정보를 내 식물에 복사. 이미 있거나 선택이 잘못되면 false
    public boolean register(String username, String nickname, Long apiId, LocalDate since) {
        Long memberId = getMemberId(username);

        if (plantRepository.findByMemberId(memberId) != null) {
            return false;
        }

        PlantApiDomain api = plantApiRepository.findById(apiId);
        if (api == null) {
            return false;
        }

        PlantDomain plant = new PlantDomain();
        plant.setMemberId(memberId);
        plant.setNickname(nickname);
        plant.setSpecies(api.getName());
        plant.setDescription(api.getDescription());
        plant.setHumidity(toHumidityText(api));
        plant.setWaterCycleDays(api.getWaterCycleDays());
        plant.setStartDate(since != null ? since : today());

        plantRepository.save(plant);
        return true;
    }

    // 습도 범위를 "40~70%" 글자로 (정보가 없으면 null)
    private String toHumidityText(PlantApiDomain api) {
        if (api.getHumidityMin() == null || api.getHumidityMax() == null) {
            return null;
        }
        return api.getHumidityMin() + "~" + api.getHumidityMax() + "%";
    }

    // 식물 삭제 (올린 사진 파일도 함께 삭제)
    public void delete(String username) throws IOException {
        PlantDomain plant = findByUsername(username);
        if (plant == null) {
            return;
        }

        // DB를 지우면 파일 이름을 알 수 없으므로 이름을 먼저 가져옴
        List<String> names = plantRepository.findPhotoNames(plant.getId());

        // DB 삭제 (사진 기록은 자동으로 같이 삭제됨)
        plantRepository.deletePlant(plant.getId());

        // DB 삭제가 성공한 뒤에 파일 삭제
        Path dir = Paths.get(uploadDir).toAbsolutePath();
        for (String name : names) {
            Files.deleteIfExists(dir.resolve(name));
        }
    }

    // 게이지 값 (0~3). 3장째에는 3/3으로 보이게 함
    public int getGauge(Long plantId) {
        int count = plantRepository.countPhotos(plantId);
        if (count > 0 && count % PHOTOS_PER_LEVEL == 0) {
            return PHOTOS_PER_LEVEL;
        }
        return count % PHOTOS_PER_LEVEL;
    }

    // 오늘(한국 시간) 사진을 이미 올렸는지
    public boolean hasUploadedToday(Long plantId) {
        return plantRepository.hasPhotoOn(plantId, today());
    }

    // 가장 최근 사진 파일 이름 (없으면 null)
    public String getLatestPhoto(Long plantId) {
        return plantRepository.findLatestPhoto(plantId);
    }

    // 사진 업로드 + 레벨업. 저장했으면 true, 규칙에 맞지 않아 저장하지 않았으면 false
    @Transactional
    public boolean addPhoto(String username, MultipartFile photo) throws IOException {
        PlantDomain plant = findByUsername(username);

        // 식물이 없거나 파일이 비어 있으면 저장하지 않음
        if (plant == null || photo.isEmpty()) {
            return false;
        }

        // 하루에 1장만 (한국 시간 기준)
        LocalDate today = today();
        if (plantRepository.hasPhotoOn(plant.getId(), today)) {
            return false;
        }

        // 이미지 확장자만 허용
        String ext = getExtension(photo.getOriginalFilename());
        if (!ALLOWED_EXT.contains(ext)) {
            return false;
        }

        // 파일 저장 (이름이 겹치지 않게 임의의 값 + 확장자)
        String fileName = UUID.randomUUID() + ext;
        Path dir = Paths.get(uploadDir).toAbsolutePath();
        Files.createDirectories(dir);
        Path target = dir.resolve(fileName);
        photo.transferTo(target);

        try {
            // DB에 사진 기록 → 개수 세기 → 레벨 변경
            plantRepository.addPhoto(plant.getId(), fileName, today);
            int count = plantRepository.countPhotos(plant.getId());
            plantRepository.updateLevel(plant.getId(), count / PHOTOS_PER_LEVEL + 1);
        } catch (RuntimeException e) {
            // DB 작업이 실패하면 방금 저장한 파일도 지움
            Files.deleteIfExists(target);
            throw e;
        }

        return true;
    }

    // 파일 이름에서 확장자 꺼내기 (예: .jpg)
    private String getExtension(String originalName) {
        if (originalName == null || originalName.lastIndexOf('.') < 0) {
            return "";
        }
        return originalName.substring(originalName.lastIndexOf('.')).toLowerCase();
    }
    
    // 로그인 아이디로 회원 번호 찾기
    private Long getMemberId(String username) {
        OmplDomain member = loginRepository.findByUsername(username);
        if (member == null) {
            throw new IllegalStateException("회원을 찾을 수 없습니다: " + username);
        }
        return member.getId();
    }
}