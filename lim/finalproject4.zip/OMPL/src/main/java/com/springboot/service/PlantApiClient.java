package com.springboot.service;

import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.springboot.domain.PlantApiDomain;

@Component
public class PlantApiClient {

    private static final String LIST_URL = "http://api.nongsaro.go.kr/service/garden/gardenList";
    private static final String DETAIL_URL = "http://api.nongsaro.go.kr/service/garden/gardenDtl";

    @Value("${nongsaro.api-key}")
    String apiKey;

    private final HttpClient httpClient = HttpClient.newHttpClient();

    // 목록 한 페이지 (번호, 이름)
    public List<PlantApiDomain> getPage(int pageNo, int size) {
        String url = LIST_URL + "?apiKey=" + apiKey + "&pageNo=" + pageNo + "&numOfRows=" + size;
        return readList(call(url));
    }

    // 이름으로 검색 (확인용)
    public List<PlantApiDomain> search(String keyword) {
        String url = LIST_URL + "?apiKey=" + apiKey + "&pageNo=1&numOfRows=20";
        if (keyword != null && !keyword.isBlank()) {
            url += "&sType=sCntntsSj&sText="
                    + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8);
        }
        return readList(call(url));
    }

    // 식물 한 개의 상세 (없으면 null)
    public PlantApiDomain getDetail(String contentNo) {
        String url = DETAIL_URL + "?apiKey=" + apiKey
                + "&cntntsNo=" + URLEncoder.encode(contentNo, StandardCharsets.UTF_8);

        NodeList items = call(url).getElementsByTagName("item");
        if (items.getLength() == 0) {
            return null;
        }
        Element item = (Element) items.item(0);

        PlantApiDomain api = new PlantApiDomain();
        api.setContentNo(getText(item, "cntntsNo"));
        api.setName(getText(item, "plntzrNm"));
        api.setHumidityCode(getText(item, "hdCode"));
        api.setWaterWinterCode(getText(item, "watercycleWinterCode"));
        String description = getText(item, "speclmanageInfo");   // 특별 관리 정보 (관리법)
        if (description == null || description.isBlank()) {
            description = getText(item, "adviseInfo");           // 비어 있으면 조언 정보로 대신
        }
        api.setDescription(description);
        return api;
    }

    // 목록 XML에서 <item>마다 번호와 이름 꺼내기
    private List<PlantApiDomain> readList(Document doc) {
        List<PlantApiDomain> result = new ArrayList<>();
        NodeList items = doc.getElementsByTagName("item");
        for (int i = 0; i < items.getLength(); i++) {
            Element item = (Element) items.item(i);

            PlantApiDomain api = new PlantApiDomain();
            api.setContentNo(getText(item, "cntntsNo"));
            api.setName(getText(item, "cntntsSj"));
            result.add(api);
        }
        return result;
    }

    // API 호출 + XML 읽기
    private Document call(String url) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
            HttpResponse<InputStream> response =
                    httpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            return factory.newDocumentBuilder().parse(response.body());

        } catch (Exception e) {
            throw new IllegalStateException("API 호출에 실패했습니다.", e);
        }
    }

    // item 안에서 태그 이름으로 글자 꺼내기 (없으면 null)
    private String getText(Element parent, String tagName) {
        NodeList list = parent.getElementsByTagName(tagName);
        if (list.getLength() == 0) {
            return null;
        }
        return list.item(0).getTextContent().trim();
    }
}