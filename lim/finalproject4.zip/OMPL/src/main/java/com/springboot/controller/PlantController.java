package com.springboot.controller;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.springboot.domain.PlantDomain;
import com.springboot.service.PlantApiService;
import com.springboot.service.PlantService;

@Controller
public class PlantController {

    @Autowired
    PlantService plantService;

    @Autowired
    PlantApiService plantApiService;

    // 식물 등록 화면
    @GetMapping("/plantnew")
    public String plantNewForm(Principal principal, Model model) {
        // 이미 식물이 있으면 등록 대신 목록으로 보냄
        if (plantService.findByUsername(principal.getName()) != null) {
            return "redirect:/plantlist";
        }
        model.addAttribute("plantApis", plantApiService.findAll());
        return "registration";
    }

    // 식물 등록 처리
    @PostMapping("/plantnew")
    public String plantNew(Principal principal,
                           @RequestParam("nickname") String nickname,
                           @RequestParam("apiId") Long apiId,
                           @RequestParam(value = "since", required = false)
                           @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate since) {

        plantService.register(principal.getName(), nickname, apiId, since);
        return "redirect:/plantlist";
    }

    // 내 식물 화면
    @GetMapping("/plantlist")
    public String plantList(Principal principal, Model model) {
        PlantDomain plant = plantService.findByUsername(principal.getName());
        model.addAttribute("plant", plant);

        if (plant != null) {
            model.addAttribute("photoCount", plantService.getGauge(plant.getId()));
            model.addAttribute("photoDone", plantService.hasUploadedToday(plant.getId()));
            model.addAttribute("latestPhoto", plantService.getLatestPhoto(plant.getId()));
        }

        return "plant_list";
    }

    // 사진 업로드 + 레벨업
    @PostMapping("/plantphoto")
    public String plantPhoto(Principal principal,
                             @RequestParam("photo") MultipartFile photo) throws IOException {

        plantService.addPhoto(principal.getName(), photo);
        return "redirect:/plantlist";
    }

    // 식물 삭제
    @PostMapping("/plantdelete")
    public String plantDelete(Principal principal) throws IOException {
        plantService.delete(principal.getName());
        return "redirect:/home";
    }
}